#include "types.h"
#include "user.h"

int main() 
	printf(1, "Calling system call %\n", cluis());
        exit();
}
