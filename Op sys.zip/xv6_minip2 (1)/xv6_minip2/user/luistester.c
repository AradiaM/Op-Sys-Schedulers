#include "types.h"
#include "user.h"

int main() {
	printf(1, "PID %\n", getpid());
        exit();
}
